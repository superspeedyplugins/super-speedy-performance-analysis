<?php
defined('ABSPATH') || exit;

/**
 * Turns a crawled job (N samples + captures) into a sspa_profiles row (medians + blob of
 * the median sample's capture) and extracts per-component aggregates into
 * sspa_component_stats so reporting never has to unpack blobs.
 */
class SSPA_Profile_Store {

    public static function save($run_id, $result) {
        global $wpdb;

        $samples = $result['samples'];
        $with_capture = array_values(array_filter($samples, function ($s) {
            return !empty($s['capture']);
        }));

        $median_capture = null;
        if ($with_capture) {
            usort($with_capture, function ($a, $b) {
                $ga = isset($a['capture']['overview']['gen_ms']) ? $a['capture']['overview']['gen_ms'] : 0;
                $gb = isset($b['capture']['overview']['gen_ms']) ? $b['capture']['overview']['gen_ms'] : 0;
                return $ga <=> $gb;
            });
            $median_capture = $with_capture[(int) floor((count($with_capture) - 1) / 2)]['capture'];
            // Reconnaissance intentionally runs on the first successful sample only. The
            // median performance capture may be another sample, so carry the privacy-safe
            // summary across without carrying the HTML it was derived from.
            if (empty($median_capture['cache_recon'])) {
                foreach ($with_capture as $sample) {
                    if (!empty($sample['capture']['cache_recon'])) {
                        $median_capture['cache_recon'] = $sample['capture']['cache_recon'];
                        break;
                    }
                }
            }
        }

        $metric = function ($path) use ($with_capture) {
            $values = array();
            foreach ($with_capture as $s) {
                $v = $s['capture'];
                foreach ($path as $key) {
                    $v = isset($v[$key]) ? $v[$key] : null;
                    if ($v === null) {
                        break;
                    }
                }
                if ($v !== null) {
                    $values[] = (float) $v;
                }
            }
            return self::median($values);
        };

        $wall_values = array();
        $codes = array();
        foreach ($samples as $s) {
            if (empty($s['blocked_by']) && empty($s['error'])) {
                $wall_values[] = $s['wall_ms'];
            }
            $codes[] = $s['code'];
        }

        $gen_ms = $metric(array('overview', 'gen_ms'));
        $sql_ms = $metric(array('sql', 'total_ms'));
        $http_ms = $metric(array('http', 'total_ms'));
        $php_ms = null;
        if ($gen_ms !== null && $sql_ms !== null) {
            $php_ms = max(0, $gen_ms - (float) $sql_ms - (float) $http_ms);
        }

        // Sample summaries only - full captures are large; the blob keeps the median one.
        $sample_summaries = array_map(function ($s) {
            $summary = array(
                'wall_ms' => $s['wall_ms'],
                'code' => $s['code'],
                'error' => $s['error'],
                'error_message' => !empty($s['error_message'])
                    ? substr(sanitize_text_field($s['error_message']), 0, 1000)
                    : null,
                'cached' => $s['cached'],
                'gen_ms' => isset($s['capture']['overview']['gen_ms']) ? round($s['capture']['overview']['gen_ms'], 1) : null,
                // Normalised response hash, so the sweep can compare a cell's output
                // against its baseline's without keeping bodies.
                'body_hash' => isset($s['body_hash']) ? $s['body_hash'] : null,
            );
            // A plugin reacted to the excluded set during this sample. Kept in the summary
            // (not only the median blob) so the sweep can spot a reacted cell without
            // unpacking blobs - the cell must be reported, never trusted as a delta.
            if (!empty($s['capture']['reactions'])) {
                $summary['reactions'] = count((array) $s['capture']['reactions']);
            }
            return $summary;
        }, $samples);

        $wpdb->insert(SSPA_Schema::table('profiles'), array(
            'run_id' => $run_id,
            'page_key' => $result['page_key'],
            'url' => $result['url'],
            // POST steps (the checkout flow) must not be recorded as GETs - the method is
            // what tells a reader that a row measured an action, not a page view.
            'method' => isset($result['method']) ? $result['method'] : 'GET',
            'variant' => $result['variant'],
            'plugin_set_hash' => isset($result['plugin_set_hash']) ? $result['plugin_set_hash'] : '',
            'object_cache_mode' => isset($result['object_cache_mode']) ? $result['object_cache_mode'] : 'normal',
            'samples' => wp_json_encode($sample_summaries),
            'ttfb_ms' => self::median($wall_values),
            'page_gen_ms' => $gen_ms,
            'sql_ms' => $sql_ms,
            'sql_count' => $metric(array('sql', 'count')),
            'http_ms' => $http_ms,
            'http_count' => $metric(array('http', 'count')),
            'php_ms' => $php_ms,
            'peak_mem_bytes' => $metric(array('overview', 'peak_mem')),
            'rows_returned_total' => $metric(array('sql', 'rows_total')),
            'dupe_query_count' => $metric(array('sql', 'dupe_count')),
            'cache_hits' => $metric(array('cache', 'hits')),
            'cache_misses' => $metric(array('cache', 'misses')),
            'mail_count' => $metric(array('mail', 'count')),
            'mail_ms' => $metric(array('mail', 'total_construct_ms')),
            'response_code' => $codes ? (int) self::median($codes) : null,
            'blocked_by' => $result['blocked_by'],
            'profile_blob' => $median_capture ? gzcompress(wp_json_encode($median_capture), 6) : null,
            'created' => gmdate('Y-m-d H:i:s'),
        ));
        $profile_id = (int) $wpdb->insert_id;

        if ($median_capture) {
            // Boot evidence (include cost, hook-callback cost, enqueued assets) used to
            // live only inside the prunable profile_blob, which made it unusable as a
            // cross-plugin contract - blobs age out after a few runs. Folding it into
            // component_stats at save time makes "did this plugin actually DO anything
            // on this page" durable and queryable. Older rows carry NULLs, which readers
            // must report as unknown, never as zero activity.
            $boot_extra = self::boot_component_evidence($median_capture);
            $seen = array();
            if (!empty($median_capture['components'])) {
                foreach ($median_capture['components'] as $component => $stats) {
                    $extra = isset($boot_extra[$component]) ? $boot_extra[$component] : array('include_ms' => null, 'hook_ms' => null, 'assets_count' => null);
                    $seen[$component] = true;
                    $wpdb->insert(SSPA_Schema::table('component_stats'), array(
                        'profile_id' => $profile_id,
                        'run_id' => $run_id,
                        'component' => substr($component, 0, 191),
                        'component_type' => $stats['type'],
                        'query_count' => (int) $stats['query_count'],
                        'sql_ms' => (float) $stats['sql_ms'],
                        'rows_returned' => (int) $stats['rows'],
                        'slowest_query_ms' => (float) $stats['slowest_ms'],
                        'http_ms' => (float) $stats['http_ms'],
                        'mail_ms' => 0,
                        'cache_hits' => 0,
                        'cache_misses' => 0,
                        'include_ms' => $extra['include_ms'],
                        'hook_ms' => $extra['hook_ms'],
                        'assets_count' => $extra['assets_count'],
                    ));
                }
            }
            // Plugins that loaded but ran no query/HTTP/mail have no aggregate row, yet
            // their include/hook/asset footprint is exactly the evidence an unload
            // decision needs - a zero-footprint row IS the finding.
            foreach ($boot_extra as $component => $extra) {
                if (isset($seen[$component]) || 'core' === $component) {
                    continue;
                }
                $wpdb->insert(SSPA_Schema::table('component_stats'), array(
                    'profile_id' => $profile_id,
                    'run_id' => $run_id,
                    'component' => substr($component, 0, 191),
                    'component_type' => 'theme' === $component ? 'theme' : 'plugin',
                    'query_count' => 0,
                    'sql_ms' => 0,
                    'rows_returned' => 0,
                    'slowest_query_ms' => 0,
                    'http_ms' => 0,
                    'mail_ms' => 0,
                    'cache_hits' => 0,
                    'cache_misses' => 0,
                    'include_ms' => $extra['include_ms'],
                    'hook_ms' => $extra['hook_ms'],
                    'assets_count' => $extra['assets_count'],
                ));
            }
        }

        return $profile_id;
    }

    /**
     * Per-component boot evidence from a capture: include cost, timed hook-callback
     * cost (boot components = includes + callbacks, so the callback share is the
     * difference), and enqueued asset count.
     *
     * @return array component => {include_ms:?float, hook_ms:?float, assets_count:?int}
     */
    private static function boot_component_evidence($capture) {
        $out = array();
        $boot = isset($capture['boot']) && is_array($capture['boot']) ? $capture['boot'] : array();
        $includes = isset($boot['includes']) && is_array($boot['includes']) ? $boot['includes'] : array();
        $combined = isset($boot['components']) && is_array($boot['components']) ? $boot['components'] : array();
        $assets = isset($boot['assets']) && is_array($boot['assets']) ? $boot['assets'] : array();

        foreach ($includes as $component => $ms) {
            $out[$component] = array('include_ms' => (float) $ms, 'hook_ms' => 0.0, 'assets_count' => 0);
        }
        foreach ($combined as $component => $ms) {
            if (!isset($out[$component])) {
                $out[$component] = array('include_ms' => null, 'hook_ms' => (float) $ms, 'assets_count' => 0);
                continue;
            }
            $out[$component]['hook_ms'] = round(max(0, (float) $ms - (float) $out[$component]['include_ms']), 2);
        }
        foreach ($assets as $component => $counts) {
            $total = (int) (isset($counts['scripts']) ? $counts['scripts'] : 0) + (int) (isset($counts['styles']) ? $counts['styles'] : 0);
            if (!isset($out[$component])) {
                $out[$component] = array('include_ms' => null, 'hook_ms' => null, 'assets_count' => $total);
                continue;
            }
            $out[$component]['assets_count'] = $total;
        }
        return $out;
    }

    public static function median($values) {
        $values = array_values(array_filter($values, function ($v) {
            return $v !== null && $v !== '';
        }));
        if (!$values) {
            return null;
        }
        sort($values);
        $count = count($values);
        $mid = (int) floor(($count - 1) / 2);
        return ($count % 2) ? $values[$mid] : ($values[$mid] + $values[$mid + 1]) / 2;
    }
}
