jQuery(function () {
	var hash = window.location.hash.replace('#', '');
	sspa_click_tab(hash || 'overview');

	// A finished run reloads the page, so sspa_autospot must be consumed exactly once -
	// left in the URL it would re-arm on every reload and loop the analysis forever.
	var autospot = window.location.search.indexOf('sspa_autospot=1') !== -1;
	if (autospot) {
		sspa_strip_autospot_param();
	}

	// Resume the floating monitor if a run is already active when the page loads.
	var active = parseInt(jQuery('#sspa-runner').data('active-run'), 10);
	if (active) {
		sspa_drive_run(active);
	} else if (autospot) {
		// Arrived from the plugin-toggle notice: run a quick spot profile of key pages.
		sspa_start_typed_run({ 'page_keys[]': ['home', 'shop', 'baseline'] }, jQuery('#sspa-run-analysis'));
	}
});

function sspa_strip_autospot_param() {
	if (!window.history || !window.history.replaceState) {
		return;
	}
	var search = window.location.search
		.replace(/([?&])sspa_autospot=1(&|$)/, function (m, before, after) {
			return after ? before : '';
		})
		.replace(/[?&]$/, '');
	window.history.replaceState(null, null, window.location.pathname + search + window.location.hash);
}

// Re-check the Tools tab in place - no page reload, so the active tab is kept.
jQuery(document).on('click', '#sspa-tools-recheck', function () {
	var btn = jQuery(this).prop('disabled', true);
	jQuery.post(ajaxurl, { action: 'sspa_tools_recheck', nonce: sspa_admin.nonce }, function (resp) {
		if (resp.success) {
			jQuery('#sspa_main div.tab-contents[data-tab="tools"]').html(resp.data.html);
		} else {
			btn.prop('disabled', false);
			alert(resp.data || 'Re-check failed.');
		}
	}).fail(function () {
		btn.prop('disabled', false);
		alert('Re-check failed.');
	});
});

// Replace an orphaned Query Monitor db.php (QM deactivated, drop-in left behind).
jQuery(document).on('click', '#sspa-replace-stale-dropin', function () {
	var btn = jQuery(this).prop('disabled', true).text('Replacing…');
	jQuery.post(ajaxurl, { action: 'sspa_replace_stale_dropin', nonce: sspa_admin.nonce }, function (resp) {
		if (resp.success) {
			// The health line lives on Overview, the install steps on Tools.
			sspa_refresh_tabs(['overview', 'tools'], function () { btn.prop('disabled', false).text('Replace'); });
		} else {
			btn.prop('disabled', false);
			alert(resp.data || 'Could not replace the drop-in.');
		}
	}).fail(function () {
		btn.prop('disabled', false);
		alert('Could not replace the drop-in.');
	});
});

jQuery(document).on('click', '#sspa_main .nav-tab-wrapper .nav-tab', function (e) {
	var slug = jQuery(this).data('tab');
	window.history.pushState(null, null, '#' + slug);
	sspa_click_tab(slug);
	e.preventDefault();
	e.stopPropagation();
});

function sspa_click_tab(slug) {
	if (!jQuery('#sspa_main .nav-tab-wrapper .nav-tab[data-tab="' + slug + '"]').length) {
		slug = 'overview';
	}
	jQuery('#sspa_main .nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
	jQuery('#sspa_main .nav-tab-wrapper .nav-tab[data-tab="' + slug + '"]').addClass('nav-tab-active').focus();
	jQuery('#sspa_main div.tab-contents').css('display', 'none');
	jQuery('#sspa_main div.tab-contents[data-tab="' + slug + '"]').css('display', 'block');
}

// ---- Attribution mode: swap the table, never reload the page ----

jQuery(document).on('click', '#sspa_main .sspa-attrib-mode', function () {
	var btn = jQuery(this);
	var mode = btn.data('mode');
	if (btn.hasClass('button-primary') || btn.prop('disabled')) {
		return;
	}
	var buttons = jQuery('#sspa_main .sspa-attrib-mode').prop('disabled', true);
	jQuery('#sspa-attrib-wrap').css('opacity', 0.5);

	jQuery.post(ajaxurl, { action: 'sspa_attribution', nonce: sspa_admin.nonce, mode: mode }, function (resp) {
		if (!resp.success) {
			alert(resp.data || 'Could not switch attribution mode.');
			return;
		}
		jQuery('#sspa-attrib-wrap').html(resp.data.html);
		jQuery('#sspa-attrib-describe').text(resp.data.describe);
		buttons.each(function () {
			var b = jQuery(this);
			var on = b.data('mode') === resp.data.mode;
			b.toggleClass('button-primary', on).attr('aria-pressed', on ? 'true' : 'false');
		});
		// Keep the mode deep-linkable without navigating away from the tab.
		if (window.history.replaceState) {
			var url = new URL(window.location.href);
			url.searchParams.set('attrib', resp.data.mode);
			// url already carries the current hash, so the tab stays selected on reload.
			window.history.replaceState(null, '', url.toString());
		}
	}).fail(function () {
		alert('Could not switch attribution mode.');
	}).always(function () {
		buttons.prop('disabled', false);
		jQuery('#sspa-attrib-wrap').css('opacity', '');
	});
});


// ---- Submission queue, driven by the browser ----
// WP-Cron only fires on traffic and many hosts disable it, so a queue that relies on it can
// sit for days. While an admin is on this screen the browser drains it; cron stays as the
// fallback for headless sites. Duplicate delivery is stopped by the compare-and-set claim in
// begin_attempt() and by the receiver's own idempotency, so this needs no locking of its own.
var sspa_ticking = false;

function sspa_drive_submissions() {
	if (sspa_ticking) {
		return;
	}
	sspa_ticking = true;
	jQuery.post(ajaxurl, { action: 'sspa_submission_tick', nonce: sspa_admin.nonce }, function (resp) {
		sspa_ticking = false;
		if (resp && resp.success && resp.data.more) {
			window.setTimeout(sspa_drive_submissions, 1500);
		} else if (resp && resp.success) {
			sspa_refresh_tabs(['share']);
		}
	}).fail(function () {
		sspa_ticking = false;
	});
}

jQuery(function () {
	if (jQuery('#sspa_main').length) {
		window.setTimeout(sspa_drive_submissions, 2000);
	}
});

// ---- Tab refresh ----
// Nothing on this screen reloads the page. A reload loses the selected tab, the scroll
// position and any open drill-down, so every action that changes server state re-renders
// only the tabs it affected.
function sspa_refresh_tabs(tabs, done) {
	jQuery.post(ajaxurl, { action: 'sspa_render_tab', nonce: sspa_admin.nonce, tabs: tabs.join(',') }, function (resp) {
		if (resp.success && resp.data.tabs) {
			Object.keys(resp.data.tabs).forEach(function (slug) {
				jQuery('#sspa_main div.tab-contents[data-tab="' + slug + '"]').html(resp.data.tabs[slug]);
			});
			jQuery('#sspa-runner').attr('data-active-run', resp.data.active_run || 0);
		}
		if (done) { done(resp); }
	}).fail(function () {
		if (done) { done(null); }
	});
}

// In-page links between tabs. These used to be hrefs to ?tab=<slug>, which reloaded the page
// AND landed on Overview anyway, because tab selection is driven by the hash.
jQuery(document).on('click', '#sspa_main .sspa-goto-tab', function (e) {
	e.preventDefault();
	var slug = jQuery(this).data('tab');
	window.history.pushState(null, null, '#' + slug);
	sspa_click_tab(slug);
});

// ---- Pages drill-down ----
// Opens THE profile panel - the same one the admin bar's "Analyse this page" opens, rendered
// by the same PHP partial. This used to build its own markup here with html += concatenation,
// which is precisely how the two views ended up showing different subsets of one capture.

jQuery(document).on('click', '.sspa-page-row', function () {
	if (!window.sspaPanel) {
		return;
	}
	window.sspaPanel.openProfile(jQuery(this).data('profile-id'));
});

function sspa_esc(str) {
	return jQuery('<span>').text(str == null ? '' : String(str)).html();
}

// Download the complete local cache optimisation evidence shown on Overview. The server
// builds a versioned document; the browser saves it without sending it anywhere else.
jQuery(document).on('click', '.sspa-cache-safety-download', function () {
	var btn = jQuery(this).prop('disabled', true);
	var status = btn.siblings('.sspa-cache-safety-download-status').text(' Preparing report…');
	jQuery.post(ajaxurl, {
		action: 'sspa_cache_recon_export',
		nonce: sspa_admin.nonce,
		run_id: btn.data('run-id')
	}, function (resp) {
		if (!resp.success) {
			status.text(' ' + (resp.data || 'The report could not be prepared.'));
			return;
		}
		var json = JSON.stringify(resp.data.payload, null, 2);
		var blob = new Blob([json], { type: 'application/json' });
		var link = document.createElement('a');
		link.href = URL.createObjectURL(blob);
		link.download = resp.data.filename || ((sspa_admin.download_prefix || '') + 'sspa-cache-optimisation-analysis.json');
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		URL.revokeObjectURL(link.href);
		status.text(' Downloaded.');
	}).fail(function () {
		status.text(' The report could not be prepared.');
	}).always(function () {
		btn.prop('disabled', false);
	});
});

// ---- Experimental traffic collector -----------------------------------

var sspaTrafficPoll = null;

function sspa_schedule_traffic_poll() {
	window.clearTimeout(sspaTrafficPoll);
	if (!jQuery('.sspa-traffic-panel[data-active="1"]').length) {
		return;
	}
	sspaTrafficPoll = window.setTimeout(function () {
		sspa_refresh_tabs(['traffic'], sspa_schedule_traffic_poll);
	}, 15000);
}

jQuery(function () {
	sspa_schedule_traffic_poll();
});

jQuery(document).on('click', '#sspa-traffic-start', function () {
	var btn = jQuery(this);
	var message = jQuery('.sspa-traffic-message');
	if (!jQuery('#sspa-traffic-confirm').prop('checked')) {
		alert('Confirm that you have read the privacy and resource limits before starting.');
		return;
	}
	btn.prop('disabled', true).text('Running database pre-flight…');
	jQuery.post(ajaxurl, {
		action: 'sspa_traffic_start',
		nonce: sspa_admin.nonce,
		duration: jQuery('#sspa-traffic-duration').val(),
		confirmed: 1
	}, function (resp) {
		if (!resp.success) {
			btn.prop('disabled', false).text('Start collection');
			alert(resp.data || 'Collection could not be started.');
			return;
		}
		message.text('Collection started.');
		sspa_refresh_tabs(['traffic'], sspa_schedule_traffic_poll);
	}).fail(function () {
		btn.prop('disabled', false).text('Start collection');
		alert('Collection could not be started.');
	});
});

jQuery(document).on('click', '#sspa-traffic-stop, #sspa-traffic-emergency-stop', function () {
	var btn = jQuery(this);
	var emergency = btn.is('#sspa-traffic-emergency-stop');
	if (emergency && !window.confirm('Remove the observer immediately? No more request or order-outcome events will be recorded.')) {
		return;
	}
	btn.prop('disabled', true);
	jQuery.post(ajaxurl, {
		action: 'sspa_traffic_stop',
		nonce: sspa_admin.nonce,
		collection_id: jQuery('.sspa-traffic-panel').data('collection-id') || 0,
		emergency: emergency ? 1 : 0
	}, function (resp) {
		if (!resp.success) {
			btn.prop('disabled', false);
			alert(resp.data || 'Collection could not be stopped.');
			return;
		}
		sspa_refresh_tabs(['traffic'], sspa_schedule_traffic_poll);
	}).fail(function () {
		btn.prop('disabled', false);
		alert('Collection could not be stopped.');
	});
});

jQuery(document).on('click', '#sspa-traffic-observations', function () {
	var btn = jQuery(this).prop('disabled', true);
	var message = jQuery('.sspa-traffic-message').text(' Preparing observations…');
	jQuery.post(ajaxurl, {
		action: 'sspa_traffic_observations',
		nonce: sspa_admin.nonce,
		collection_id: jQuery('.sspa-traffic-panel').data('collection-id') || 0
	}, function (resp) {
		if (!resp.success) {
			message.text(' ' + (resp.data || 'Observations could not be prepared.'));
			return;
		}
		var json = JSON.stringify(resp.data.payload, null, 2);
		var blob = new Blob([json], { type: 'application/json' });
		var link = document.createElement('a');
		link.href = URL.createObjectURL(blob);
		link.download = resp.data.filename || ((sspa_admin.download_prefix || '') + 'sspa-experimental-traffic-observations.json');
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		URL.revokeObjectURL(link.href);
		message.text(' Downloaded.');
	}).fail(function () {
		message.text(' Observations could not be prepared.');
	}).always(function () {
		btn.prop('disabled', false);
	});
});

jQuery(document).on('click', '#sspa-traffic-delete', function () {
	if (!window.confirm('Permanently delete this collection, all raw event rows and its temporary join key?')) {
		return;
	}
	var btn = jQuery(this).prop('disabled', true);
	jQuery.post(ajaxurl, {
		action: 'sspa_traffic_delete',
		nonce: sspa_admin.nonce,
		collection_id: jQuery('.sspa-traffic-panel').data('collection-id') || 0
	}, function (resp) {
		if (!resp.success) {
			btn.prop('disabled', false);
			alert(resp.data || 'Collection data could not be deleted.');
			return;
		}
		sspa_refresh_tabs(['traffic'], sspa_schedule_traffic_poll);
	}).fail(function () {
		btn.prop('disabled', false);
		alert('Collection data could not be deleted.');
	});
});

// ---- Plugins drill-down: per-page x cache-mode measured impacts ----

jQuery(document).on('click', '.sspa-impact-details', function (e) {
	e.preventDefault();
	var link = jQuery(this);
	var row = link.closest('tr');
	var existing = row.next('.sspa-impact-detail-row');
	if (existing.length) {
		existing.toggle();
		return;
	}
	var cols = row.children('td').length;
	var detail = jQuery('<tr class="sspa-impact-detail-row"><td colspan="' + cols + '">Loading&hellip;</td></tr>');
	row.after(detail);
	jQuery.post(ajaxurl, { action: 'sspa_plugin_detail', nonce: sspa_admin.nonce, plugin: link.data('plugin') }, function (resp) {
		if (!resp.success) {
			detail.children('td').text(resp.data || 'No detail available.');
			return;
		}
		var rows = resp.data.rows;
		var modeOrder = ['normal', 'disabled', 'prime', 'warm'];
		var modeLabels = { normal: 'Standard (cache warm)', disabled: 'No object cache', prime: 'Cache priming', warm: 'Warm cache' };
		var modes = modeOrder.filter(function (m) {
			return rows.some(function (r) { return r.object_cache_mode === m; });
		});
		var byPage = {};
		rows.forEach(function (r) {
			(byPage[r.page_key] = byPage[r.page_key] || {})[r.object_cache_mode] = r;
		});
		var version = resp.data.measured_version;
		var html = '<div class="sspa-detail"><h4>Measured impact of <code>' + sspa_esc(link.data('plugin')) + '</code>'
			+ (version ? ' version <code>' + sspa_esc(version) + '</code>' : '')
			+ ' per page</h4>';
		html += '<table class="widefat"><thead><tr><th>Page</th>';
		modes.forEach(function (m) {
			html += '<th>' + modeLabels[m] + '</th>';
		});
		html += '</tr></thead><tbody>';
		Object.keys(byPage).forEach(function (page) {
			html += '<tr><td><code>' + sspa_esc(page) + '</code></td>';
			modes.forEach(function (m) {
				var r = byPage[page][m];
				html += '<td>' + (r ? sspa_impact_cell(r) : '-') + '</td>';
			});
			html += '</tr>';
		});
		html += '</tbody></table>';
		html += '<p class="description">"adds" = the plugin costs that much page-generation time; "saves" = the page is SLOWER without it (the plugin is speeding it up); "within noise" = no measurable difference on that page.</p></div>';
		detail.children('td').html(html);
	});
});

function sspa_impact_cell(r) {
	if (r.confidence !== 'measured') {
		return '<span class="sspa-impact-noise">within &plusmn;' + Math.round(r.noise_floor_ms) + 'ms noise</span>';
	}
	var d = parseFloat(r.delta_ttfb_ms);
	var cls = d < 0 ? 'sspa-impact-saves' : 'sspa-impact-adds';
	var label = (d < 0 ? 'saves ' : 'adds ') + Math.abs(Math.round(d)) + 'ms';
	var sql = Math.round(parseFloat(r.delta_sql_ms));
	var q = parseInt(r.delta_queries, 10);
	var sub = 'SQL ' + (sql >= 0 ? '+' : '−') + Math.abs(sql) + 'ms · ' + (q >= 0 ? '+' : '−') + Math.abs(q) + ' queries';
	return '<strong class="' + cls + '">' + label + '</strong><br><small>' + sub + '</small>';
}

// ---- Prune stored blobs ----

jQuery(document).on('click', '#sspa-prune-blobs', function () {
	var keep = jQuery(this).data('keep');
	if (!confirm('Delete detailed per-query data for all but the last ' + keep + ' runs?\n\nSummary metrics, findings and history are always kept. If sharing is enabled, every affected run is first saved to the durable local submission queue.')) {
		return;
	}
	jQuery.post(ajaxurl, { action: 'sspa_prune_blobs', nonce: sspa_admin.nonce }, function (resp) {
		if (resp.success) {
			alert('Done. Detailed data now uses ' + resp.data.human + '.');
			sspa_refresh_tabs(['overview', 'tools', 'history', 'share']);
		}
	});
});

// ---- Share tab ----

jQuery(document).on('change', '#sspa-share-optin', function () {
	var optin = jQuery(this).is(':checked') ? 1 : 0;
	jQuery.post(ajaxurl, { action: 'sspa_share_optin', nonce: sspa_admin.nonce, optin: optin }, function (resp) {
		if (!resp.success) {
			alert(resp.data || 'Could not update sharing consent.');
			sspa_refresh_tabs(['share']);
			return;
		}
		jQuery('.sspa-sharing-action').prop('disabled', !optin);
	});
});

// Per-plugin publishing. Independent of the site-wide setting above: a site owner can let one
// plugin publish its settings and refuse another without turning sharing off altogether.
jQuery(document).on('change', '.sspa-publisher-toggle', function () {
	var box = jQuery(this);
	var enabled = box.is(':checked') ? 1 : 0;
	jQuery.post(ajaxurl, {
		action: 'sspa_publisher_toggle',
		nonce: sspa_admin.nonce,
		slug: box.val(),
		enabled: enabled
	}, function (resp) {
		if (!resp.success) {
			alert(resp.data || 'Could not update this plugin.');
			// Put the box back where it was rather than leaving the screen claiming something
			// the site does not believe.
			box.prop('checked', !enabled);
		}
	}).fail(function () {
		alert('Could not update this plugin.');
		box.prop('checked', !enabled);
	});
});

jQuery(document).on('click', '.sspa-preview-outbox', function () {
	var pre = jQuery('#sspa-payload-preview');
	var summary = jQuery('#sspa-payload-summary');
	var outboxId = jQuery(this).data('outbox-id') || 0;
	if (pre.is(':visible') && pre.data('outbox-id') === outboxId) {
		pre.hide();
		summary.hide();
		return;
	}
	pre.data('outbox-id', outboxId).text('Building the exact payload…').show();
	summary.hide();
	jQuery.post(ajaxurl, { action: 'sspa_payload_preview', nonce: sspa_admin.nonce, outbox_id: outboxId }, function (resp) {
		if (!resp.success) {
			pre.text(resp.data || 'Could not build the payload.');
			return;
		}
		pre.text(resp.data.payload);
		summary.html(sspa_payload_summary_html(resp.data)).show();
		// Download is built from the payload already in hand - no second request, and the file
		// is byte-identical to what was shown.
		summary.find('.sspa-download-payload').on('click', function (e) {
			e.preventDefault();
			var blob = new Blob([resp.data.payload], { type: 'application/json' });
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = resp.data.filename || ((sspa_admin.download_prefix || '') + 'sspa-shared-data.json');
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(a.href);
		});
	});
});

// Plain English above the JSON. Most people do not read JSON, and they are exactly the people
// a privacy promise has to convince.
function sspa_payload_summary_html(data) {
	var s = data.summary || {};
	var kb = Math.max(1, Math.round((data.bytes || 0) / 1024));
	var html = '<p><strong>This is everything that would be sent';
	if (s.run_type) { html += ' for this ' + sspa_esc(s.run_type) + ' analysis'; }
	html += ' (' + kb + ' KB).</strong></p>';
	if (s.includes && s.includes.length) {
		html += '<p>It contains: ';
		html += s.includes.map(function (i) { return sspa_esc(i); }).join(', ');
		if (s.components) { html += ', and the names and versions of ' + s.components + ' active components'; }
		html += '.</p>';
	}
	// Named, not counted. "Which plugins are publishing their settings" is the one question the
	// narrower exclusion below raises, and it should not need the JSON to answer.
	if (s.state_components && s.state_components.length) {
		html += '<p>These plugins have opted in to publishing their own performance settings: ';
		html += s.state_components.map(function (i) { return '<code>' + sspa_esc(i) + '</code>'; }).join(', ');
		html += '.</p>';
	}
	if (s.excludes && s.excludes.length) {
		html += '<p>It does <strong>not</strong> contain ';
		html += s.excludes.map(function (i) { return sspa_esc(i); }).join('; ');
		html += '.</p>';
	}
	html += '<p><a href="#" class="button button-small sspa-download-payload">Download this file</a></p>';
	return html;
}

// Share one analysis on its own. Deliberately no confirm()/alert(): the outcome is reported
// in the cell itself, so the answer stays next to the run it refers to.
jQuery(document).on('click', '.sspa-share-run', function () {
	var btn = jQuery(this).prop('disabled', true);
	var cell = btn.closest('.sspa-share-run-cell');
	cell.find('.sspa-share-run-result').remove();
	btn.after(' <span class="sspa-share-run-result description">Preparing the anonymised payload…</span>');
	jQuery.post(ajaxurl, {
		action: 'sspa_share_run',
		nonce: sspa_admin.nonce,
		run_id: btn.data('run-id')
	}, function (resp) {
		if (!resp.success) {
			cell.find('.sspa-share-run-result').text(resp.data || 'Could not share this analysis.');
			btn.prop('disabled', false);
			return;
		}
		btn.remove();
		cell.find('.sspa-share-run-result').html(
			'Queued to share (this run only) - ' + resp.data.compressed_bytes + ' bytes. ' +
			'<button type="button" class="button button-small sspa-preview-outbox" data-outbox-id="' + resp.data.outbox_id + '">Preview data</button>'
		);
	}).fail(function () {
		cell.find('.sspa-share-run-result').text('Could not share this analysis.');
		btn.prop('disabled', false);
	});
});

jQuery(document).on('click', '#sspa-submit-now', function () {
	var btn = jQuery(this).prop('disabled', true);
	jQuery.post(ajaxurl, { action: 'sspa_submit_now', nonce: sspa_admin.nonce }, function (resp) {
		alert(resp.success ? 'Queued locally. Delivery runs in the background and retries automatically.' : (resp.data || 'Could not queue the submission.'));
		sspa_refresh_tabs(['share', 'history'], function () { btn.prop('disabled', false); });
		sspa_drive_submissions();
	}).fail(function () {
		alert('Could not queue the submission.');
		btn.prop('disabled', false);
	});
});

jQuery(document).on('click', '#sspa-backfill', function () {
	var btn = jQuery(this).prop('disabled', true);
	var status = jQuery('#sspa-backfill-status');
	var restart = parseInt(btn.data('restart'), 10) ? 1 : 0;
	var totalQueued = 0;
	var totalFailed = 0;

	function nextBatch(first) {
		status.text('Building a bounded batch of historical payloads…');
		jQuery.post(ajaxurl, {
			action: 'sspa_community_backfill',
			nonce: sspa_admin.nonce,
			restart: first ? restart : 0
		}, function (resp) {
			if (!resp.success) {
				status.text(resp.data || 'Historical queueing failed.');
				btn.prop('disabled', false);
				return;
			}
			totalQueued += parseInt(resp.data.queued, 10) || 0;
			totalFailed += (resp.data.failed || []).length;
			status.text('Queued ' + totalQueued + '; ' + resp.data.inventory.remaining + ' historical run(s) remain.');
			if (!resp.data.complete) {
				window.setTimeout(function () { nextBatch(false); }, 250);
				return;
			}
			alert('Historical queueing finished: ' + totalQueued + ' queued, ' + totalFailed + ' requiring review.');
			sspa_refresh_tabs(['share', 'history']);
			sspa_drive_submissions();
		}).fail(function () {
			status.text('Historical queueing request failed. Progress has been saved; press the button to resume.');
			btn.prop('disabled', false);
		});
	}

	nextBatch(true);
});

jQuery(document).on('click', '.sspa-outbox-action', function () {
	var btn = jQuery(this);
	var operation = btn.data('operation');
	if (operation === 'pause' && !confirm('Pause this submission? Its exact local payload will be retained and can be resumed later.')) {
		return;
	}
	btn.prop('disabled', true);
	jQuery.post(ajaxurl, {
		action: 'sspa_outbox_action',
		nonce: sspa_admin.nonce,
		outbox_id: btn.data('outbox-id'),
		operation: operation
	}, function (resp) {
		if (!resp.success) {
			alert(resp.data || 'Could not update the submission.');
			btn.prop('disabled', false);
			return;
		}
		sspa_refresh_tabs(['share', 'history']);
		sspa_drive_submissions();
	}).fail(function () {
		alert('Could not update the submission.');
		btn.prop('disabled', false);
	});
});

// ---- Run Analysis ----

jQuery(document).on('click', '#sspa-run-analysis', function () {
	sspa_start_typed_run({}, jQuery(this));
});

// Plugin Impact Analysis never starts from one press any more. The button opens the plugin
// picker (rendered by sspa-adhoc.js into the panel shell): nothing is measured until the
// site owner ticks the plugins themselves, with the estimate and the caution in front of
// them. Measuring a plugin means excluding it from test requests, and which plugins that is
// acceptable for is their call, not a default.
jQuery(document).on('click', '#sspa-run-deep', function () {
	if (window.sspaPanel && window.sspaPanel.openImpactPicker) {
		window.sspaPanel.openImpactPicker();
	}
});

jQuery(document).on('click', '#sspa-run-cache', function () {
	sspa_start_typed_run({ type: 'cache_impact' }, jQuery(this));
});

jQuery(document).on('click', '.sspa-measure-plugin', function () {
	var plugin = jQuery(this).data('plugin');
	if (!confirm('Measure "' + plugin + '" on every profiled page with the plugin disabled for the test requests only? Visitors are unaffected.')) {
		return;
	}
	sspa_start_typed_run({ type: 'deep', 'suspects[]': plugin }, jQuery(this));
});

function sspa_start_typed_run(extra, btn) {
	btn.prop('disabled', true);
	var payload = jQuery.extend({
		action: 'sspa_start_run',
		nonce: sspa_admin.nonce,
		swap_dropin: jQuery('#sspa-swap-dropin').is(':checked') ? 1 : 0,
		include_writes: jQuery('#sspa-include-writes').is(':checked') ? 1 : 0
	}, extra);
	jQuery.post(ajaxurl, payload, function (resp) {
		if (!resp.success) {
			alert(resp.data || 'Could not start the analysis.');
			btn.prop('disabled', false);
			return;
		}
		// No tab switch, no reload: the floating monitor shows progress wherever you are.
		sspa_drive_run(resp.data.run_id);
	}).fail(function () {
		alert('Could not start the analysis (request failed).');
		btn.prop('disabled', false);
	});
}

jQuery(document).on('click', '#sspa-cancel-run, #sspa-runner-cancel', function () {
	if (!confirm('Cancel the running analysis?')) {
		return;
	}
	jQuery.post(ajaxurl, { action: 'sspa_cancel_run', nonce: sspa_admin.nonce }, function () {
		sspa_runner_dismiss();
		sspa_refresh_tabs(['overview', 'history']);
	});
});

// ---- Floating run monitor ----

jQuery(document).on('click', '#sspa-runner .sspa-runner-head', function (e) {
	if (jQuery(e.target).is('#sspa-runner-cancel')) {
		return;
	}
	var runner = jQuery('#sspa-runner');
	runner.toggleClass('sspa-runner-min');
	sspa_runner_backdrop(runner);
	try {
		window.localStorage.setItem('sspa_runner_min', runner.hasClass('sspa-runner-min') ? '1' : '0');
	} catch (err) { /* private mode */ }
	e.preventDefault();
});

function sspa_runner_show() {
	var runner = jQuery('#sspa-runner');
	try {
		if (window.localStorage.getItem('sspa_runner_min') === '1') {
			runner.addClass('sspa-runner-min');
		}
	} catch (err) { /* private mode */ }
	runner.show();
	sspa_runner_backdrop(runner);
}

// The dimmer belongs to the centred panel only. Minimised, the screen has to stay usable.
function sspa_runner_backdrop(runner) {
	var wanted = runner.is(':visible') && !runner.hasClass('sspa-runner-min');
	var backdrop = jQuery('#sspa-runner-backdrop');
	if (wanted && !backdrop.length) {
		jQuery('<div id="sspa-runner-backdrop">').insertBefore(runner);
	} else if (!wanted) {
		backdrop.remove();
	}
}

function sspa_fmt_duration(seconds) {
	if (seconds === null || seconds === undefined || isNaN(seconds)) {
		return null;
	}
	seconds = Math.max(0, Math.round(seconds));
	var h = Math.floor(seconds / 3600);
	var m = Math.floor((seconds % 3600) / 60);
	if (h > 0) {
		return h + 'h ' + m + 'm';
	}
	if (m > 0) {
		return m + 'm';
	}
	return seconds + 's';
}

// Highest job index already accepted into the feed, so a poll only queues what is new.
// A fast site can still finish two measurements between status polls; reveal those in order
// instead of making the monitor appear frozen and then dumping several lines at once.
var sspa_feed_seen = -1;
var sspa_feed_queue = [];
var sspa_feed_timer = null;
var sspa_feed_current = null;

function sspa_runner_feed_tail(feed, current) {
	var el = feed.get(0);
	var following = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
	feed.find('.sspa-feed-now').remove();
	if (current) {
		feed.append(jQuery('<li class="sspa-feed-now">').text(current + ' …'));
	}
	if (following) {
		el.scrollTop = el.scrollHeight;
	}
}

function sspa_runner_feed_drain() {
	var feed = jQuery('#sspa-runner .sspa-runner-feed');
	if (!feed.length || !sspa_feed_queue.length) {
		sspa_feed_timer = null;
		if (feed.length) {
			sspa_runner_feed_tail(feed, sspa_feed_current);
		}
		return;
	}

	var el = feed.get(0);
	var following = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
	feed.find('.sspa-feed-now').remove();
	feed.append(jQuery('<li>').text(sspa_feed_queue.shift().label));
	if (sspa_feed_current) {
		feed.append(jQuery('<li class="sspa-feed-now">').text(sspa_feed_current + ' …'));
	}
	if (following) {
		el.scrollTop = el.scrollHeight;
	}

	sspa_feed_timer = setTimeout(sspa_runner_feed_drain, 140);
}

function sspa_runner_feed(s) {
	var feed = jQuery('#sspa-runner .sspa-runner-feed');
	if (!feed.length) {
		return;
	}
	sspa_feed_current = s.current || null;

	(s.recent || []).forEach(function (item) {
		if (item.i > sspa_feed_seen) {
			sspa_feed_seen = item.i;
			sspa_feed_queue.push(item);
		}
	});

	if (!sspa_feed_timer && sspa_feed_queue.length) {
		sspa_runner_feed_drain();
	} else {
		// The in-flight measurement sits at the bottom until it completes and arrives in recent.
		sspa_runner_feed_tail(feed, sspa_feed_current);
	}
}

function sspa_runner_update(s) {
	var runner = jQuery('#sspa-runner');
	var pct = s.total ? Math.min(100, Math.round((s.done / s.total) * 100)) : 0;
	runner.find('.sspa-progress-fill').css('width', pct + '%');
	// The phase belongs next to the number, not only in the title: a total that jumps from 72
	// to 216 mid-run reads as a bug unless the screen says why.
	var counts = s.done + ' / ' + s.total + ' measurements (' + pct + '%)';
	if (s.run_type === 'deep' && s.phase) {
		counts = (s.phase === 1 ? 'Phase 1/2, screening' : 'Phase 2/2, confirming') + ' \u00b7 ' + counts;
	}
	runner.find('.sspa-runner-counts').text(counts);
	runner.find('.sspa-runner-current').text(s.current ? 'Now testing: ' + s.current : (s.status === 'analysing' ? 'Analysing results…' : ''));
	sspa_runner_feed(s);
	var eta = sspa_fmt_duration(s.eta_seconds);
	var elapsed = sspa_fmt_duration(s.elapsed_seconds);
	var bits = [];
	if (elapsed) {
		bits.push('Elapsed ' + elapsed);
	}
	if (eta) {
		// Phase 1 is the fast screen; phase 2 length depends on what it finds.
		bits.push('~' + eta + (s.run_type === 'deep' && s.phase === 1 ? ' left in screening' : ' left'));
	}
	runner.find('.sspa-runner-eta').text(bits.join(' · '));
	runner.find('.sspa-runner-mini-summary').text(pct + '%' + (eta ? ' · ~' + eta + ' left' : ''));
	var title = { deep: 'Plugin impact analysis running', cache_impact: 'Cache impact analysis running' }[s.run_type] || 'Analysis running';
	if (s.run_type === 'deep' && s.phase) {
		title += s.phase === 1 ? ' - phase 1/2: screening all plugins' : ' - phase 2/2: confirming impacted plugins';
	}
	runner.find('.sspa-runner-title').text(title);
}

// Take the panel down and release the dimmer, without touching the page.
function sspa_runner_dismiss() {
	var runner = jQuery('#sspa-runner').hide().removeClass('sspa-runner-min');
	runner.find('.sspa-runner-current, .sspa-runner-eta, .sspa-runner-actions').show();
	runner.find('.sspa-runner-feed').empty();
	sspa_feed_seen = -1;
	sspa_feed_queue = [];
	sspa_feed_current = null;
	if (sspa_feed_timer) {
		clearTimeout(sspa_feed_timer);
		sspa_feed_timer = null;
	}
	sspa_runner_backdrop(runner);
}

function sspa_runner_finish(status) {
	var runner = jQuery('#sspa-runner').removeClass('sspa-runner-min');
	var label = status === 'done' ? 'Analysis complete ✓ loading results…' : 'Analysis ' + status + ' - loading results…';
	runner.find('.sspa-runner-title').text(label);
	runner.find('.sspa-runner-mini-summary').text('');
	runner.find('.sspa-progress-fill').css('width', '100%');
	runner.find('.sspa-runner-current, .sspa-runner-eta, .sspa-runner-actions').hide();
	sspa_runner_backdrop(runner);
	// Every tab a run can change. The results appear under whichever tab the user is already
	// looking at, rather than throwing them back to Overview via a reload.
	sspa_refresh_tabs(['overview', 'pages', 'plugins', 'history', 'share'], function () {
		sspa_runner_dismiss();
	});
}

// The browser drives batches sequentially; WP-Cron is the backup for headless progress,
// and the hourly janitor re-kicks a run whose driver disappeared.
//
// Browser-transport runs (loopbacks blocked at preflight - basic auth, WAF, CDN): the
// server-side pump no-ops while SSPATransport.drive() fetches pages from THIS browser one
// request at a time; the independent status poll below monitors both transport modes.
function sspa_drive_run(runId) {
	sspa_runner_show();
	jQuery('#sspa-run-analysis, #sspa-run-deep, #sspa-run-cache, .sspa-measure-plugin').prop('disabled', true);
	jQuery('#sspa-cancel-run').show();

	var failures = 0;
	var browserDriver = null;
	var stopped = false;
	var batchTimer = null;
	var statusTimer = null;
	var statusRequest = null;

	function finish(status) {
		if (stopped) {
			return;
		}
		stopped = true;
		if (batchTimer) {
			clearTimeout(batchTimer);
		}
		if (statusTimer) {
			clearTimeout(statusTimer);
		}
		if (statusRequest) {
			statusRequest.abort();
		}
		if (browserDriver) {
			browserDriver.stop();
		}
		sspa_runner_finish(status);
	}

	// process_batch deliberately keeps one request busy for up to 15 seconds. Poll the
	// read-only status endpoint alongside it so every saved measurement reaches the monitor
	// as it completes instead of all completed measurements arriving with the batch response.
	function pollStatus() {
		if (stopped) {
			return;
		}
		statusRequest = jQuery.post(ajaxurl, { action: 'sspa_run_status', nonce: sspa_admin.nonce, run_id: runId }, function (resp) {
			if (stopped || !resp.success || !resp.data) {
				return;
			}
			var s = resp.data;
			sspa_runner_update(s);
			if (s.status !== 'crawling' && s.status !== 'analysing') {
				finish(s.status);
			}
		}).always(function () {
			statusRequest = null;
			if (!stopped) {
				statusTimer = setTimeout(pollStatus, 350);
			}
		});
	}

	function step() {
		if (stopped) {
			return;
		}
		jQuery.post(ajaxurl, { action: 'sspa_process_batch', nonce: sspa_admin.nonce, run_id: runId }, function (resp) {
			if (stopped) {
				return;
			}
			failures = 0;
			if (!resp.success || !resp.data) {
				finish('finished');
				return;
			}
			var s = resp.data;
			sspa_runner_update(s);
			if (s.status === 'crawling' || s.status === 'analysing') {
				if (s.transport === 'browser' && s.status === 'crawling' && !browserDriver && window.SSPATransport) {
					console.info('[SSPA] loopbacks are blocked on this site - this browser is fetching the pages itself');
					browserDriver = SSPATransport.drive({
						ajaxurl: ajaxurl,
						nonce: sspa_admin.nonce,
						runId: runId,
						onFail: function (message) {
							console.error('[SSPA] browser transport stopped: ' + message);
						}
					});
				}
				batchTimer = setTimeout(step, 400);
			} else {
				finish(s.status);
			}
		}).fail(function () {
			if (stopped) {
				return;
			}
			// Transient network/server hiccups must not kill an hours-long run.
			failures++;
			jQuery('#sspa-runner .sspa-runner-current').text(failures > 1 ? 'Connection hiccup, retrying… (' + failures + ')' : '');
			batchTimer = setTimeout(step, Math.min(30000, 3000 * failures));
		});
	}

	pollStatus();
	step();
}

// --- Tools tab: installation steps + copy to clipboard ---------------------
// Steps are inert text. Nothing here installs, edits or restarts anything; the user runs
// the commands themselves, or sends them to their host.
jQuery(function ($) {
	$(document).on('click', '.sspa-steps-toggle', function () {
		var $btn = $(this);
		var $row = $('#' + $btn.data('target'));
		var open = $row.is(':visible');
		$row.toggle(!open);
		$btn.attr('aria-expanded', open ? 'false' : 'true')
			.text(open ? sspa_tools_i18n.show : sspa_tools_i18n.hide);
	});

	$(document).on('click', '.sspa-copy', function () {
		var $btn = $(this);
		var text = $btn.closest('.sspa-code-block').find('code').text();
		var done = function () {
			var original = $btn.text();
			$btn.text(sspa_tools_i18n.copied);
			setTimeout(function () { $btn.text(original); }, 1500);
		};
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(done, function () {});
			return;
		}
		// Fallback for non-secure contexts, where the clipboard API is unavailable.
		var $tmp = $('<textarea>').val(text).css({position: 'fixed', opacity: 0}).appendTo('body');
		$tmp[0].select();
		try { document.execCommand('copy'); done(); } catch (e) {}
		$tmp.remove();
	});
});
