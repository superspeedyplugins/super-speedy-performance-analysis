<?php

namespace SuperSpeedy\PluginUpdateChecker\v5;

if ( !class_exists(PucFactory::class, false) ):

	class PucFactory extends \SuperSpeedy\PluginUpdateChecker\v5p4\PucFactory {
	}

endif;
